#!/bin/sh

JAVAPATH=/opt/ibm/java/bin
CLASSPATH=./lib:./lib/businessobjects.jar:./lib/icu4j.jar:./lib/json4j.jar:./lib/log4j-1.2.16.jar:./lib/mail.jar

ERRMSG=エラーが発生したため処理を終了します。
